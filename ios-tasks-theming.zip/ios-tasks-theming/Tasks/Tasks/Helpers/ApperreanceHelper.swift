//
//  ApperreanceHelper.swift
//  Tasks
//
//  Created by Iyin Raphael on 8/27/18.
//  Copyright © 2018 Andrew R Madsen. All rights reserved.
//

import UIKit

class Appearance {
    static var backgroundGray = UIColor(red: 45.0/255.0, green: 45.0/255.0, blue: 45.0/255.0, alpha: 1.0)
    
    static func setDarkAppearances() {
        UINavigationBar.appearance().barTintColor = backgroundGray
        UINavigationBar.appearance().tintColor = .cyan
        UISegmentedControl.appearance().tintColor = .cyan
        
        let textAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
        UINavigationBar.appearance().titleTextAttributes = textAttributes
        UINavigationBar.appearance().largeTitleTextAttributes = textAttributes
        

         UITableViewCell.appearance().backgroundColor = backgroundGray
        
        UILabel.appearance().textColor = .white

    }
    static func applicationFont(with textStyle: UIFontTextStyle, pointSize: CGFloat) -> UIFont {
        let result = UIFont(name: "RM Typerighter medium", size: pointSize)!
        return UIFontMetrics(forTextStyle: textStyle).scaledFont(for: result)
    }
}
