//
//  RecordViewController.swift
//  PutAndPost
//
//  Created by Iyin Raphael on 8/15/18.
//  Copyright © 2018 Iyin Raphael. All rights reserved.
//

import UIKit

class RecordViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func demonstratePut(_ sender: Any) {
    }
    @IBAction func demonstratePOST(_ sender: Any) {
    }
    @IBAction func demonstratePOST2(_ sender: Any) {
    }
    @IBOutlet weak var modelLabel: UILabel!
    @IBOutlet weak var identifierLabel: UILabel!
    
    @IBOutlet weak var dataRecordLabel: UILabel!
}
