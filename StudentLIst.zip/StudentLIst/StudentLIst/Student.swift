//
//  Student.swift
//  StudentLIst
//
//  Created by Iyin Raphael on 8/13/18.
//  Copyright © 2018 Iyin Raphael. All rights reserved.
//

import Foundation

struct Student: Equatable {
    
    let name: String
}
